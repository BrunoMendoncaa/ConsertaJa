# TecnoFix — textos para anúncios e WhatsApp

Público: donos e gerentes de assistência técnica (celular, informática, TV, eletro).
Oferta: **teste grátis por 14 dias, sem cartão de crédito**. Sem preço nos anúncios.
Link de destino: **https://tecnofix.pro** (a página explica e leva ao cadastro).
Botão sugerido no Meta: **Cadastre-se** (ou **Saiba mais**).

Limites do Meta que valem lembrar: o texto principal aparece inteiro até ~125 caracteres
(o resto fica no "ver mais"); título até ~40; descrição até ~30.

---

## 1. Anúncio "Caderno" — imagens `os-caderno-*`

**Texto principal (curto)**
Ainda anota as ordens de serviço no caderno? No TecnoFix a OS sai em menos de 1 minuto, com fotos e comprovante com QR code.

**Texto principal (longo)**
Caderno molha, some e ninguém entende a letra do outro. 📒❌
No TecnoFix você abre a ordem de serviço em menos de 1 minuto:
✅ cliente e aparelho cadastrados
✅ checklist de entrada e fotos
✅ comprovante com QR code para imprimir
✅ link para o cliente acompanhar o conserto
Teste grátis por 14 dias, sem cartão de crédito.

**Título:** Troque o caderno pelo TecnoFix
**Descrição:** 14 dias grátis, sem cartão

---

## 2. Anúncio "Aprovação pelo celular" — imagens e vídeo `aprovacao-celular-*`

**Texto principal (curto)**
Seu cliente vê o orçamento no celular e aprova com um toque. Sem ligação, sem "vou ver e te falo".

**Texto principal (longo)**
Quantos orçamentos ficam parados esperando o cliente responder? 📱
Com o TecnoFix você manda o link pelo WhatsApp, o cliente abre, vê cada peça e serviço e aprova na hora.
✅ aprovação registrada com data e hora
✅ você é avisado no sistema
✅ nada de áudio perdido no meio da conversa
Teste grátis por 14 dias, sem cartão.

**Título:** Orçamento aprovado pelo celular
**Descrição:** Teste grátis por 14 dias

---

## 3. Anúncio "Já ficou pronto?" — imagens `ja-ficou-pronto-*`

**Texto principal (curto)**
Menos "já ficou pronto?" no seu WhatsApp. Cada cliente acompanha o conserto pelo link, etapa por etapa.

**Texto principal (longo)**
"Já ficou pronto?" "Alguma novidade?" "Consegue ver hoje?" 😅
Com o TecnoFix cada cliente recebe um link (e um código de acesso) para acompanhar o conserto: recebido, em análise, orçamento, conserto, pronto e entregue.
Menos mensagem para responder, mais tempo na bancada.
Teste grátis por 14 dias, sem cartão de crédito.

**Título:** Seu cliente acompanha sozinho
**Descrição:** 14 dias grátis, sem cartão

---

## 4. Anúncio "Comprovante e garantia" — imagens `comprovante-garantia-*` e vídeo `entrega-garantia-*`

**Texto principal (curto)**
Comprovante de entrada com QR code e certificado de garantia prontos para imprimir. Mais confiança na entrada e na entrega.

**Texto principal (longo)**
Cliente confia mais quando recebe tudo no papel, certinho. 🧾
No TecnoFix:
✅ comprovante de entrada com QR code, acessórios e estado do aparelho
✅ certificado de garantia gerado na entrega, com prazo, serviço e peças
✅ sua marca, seus dados e suas condições
Teste grátis por 14 dias, sem cartão.

**Título:** Garantia e comprovante na hora
**Descrição:** Teste grátis por 14 dias

---

## 5. Anúncio "Faturamento" — imagens `faturamento-*`

**Texto principal (curto)**
Quanto sua assistência faturou este mês? No TecnoFix você vê na hora: caixa, orçamentos, valores a receber e relatórios.

**Texto principal (longo)**
Se a resposta para "quanto entrou este mês?" é "deixa eu ver a planilha…", está na hora de mudar. 📊
O TecnoFix junta tudo num painel só:
✅ entradas e saídas do caixa
✅ orçamentos aprovados e valores a receber
✅ ticket médio e taxa de aprovação
✅ relatórios por período
Teste grátis por 14 dias, sem cartão de crédito.

**Título:** Os números da sua assistência
**Descrição:** 14 dias grátis, sem cartão

---

## 6. Vídeo "Nova OS" — `video-nova-os-*`

**Texto principal**
Cronometra aí: uma ordem de serviço completa, do cadastro do cliente ao link de acompanhamento, em menos de 1 minuto. ⏱️
Teste o TecnoFix grátis por 14 dias, sem cartão.

**Título:** OS completa em menos de 1 minuto
**Descrição:** Teste grátis por 14 dias

---

## Legendas para Status do WhatsApp

Use com as imagens "stories" ou os vídeos "stories". O link escrito vira clicável no Status.

1. Ainda anotando OS no caderno? 📒 Conheça o TecnoFix, sistema para assistência técnica. 14 dias grátis: tecnofix.pro
2. Seu cliente aprova o orçamento pelo celular, com um toque. 📱 Teste grátis: tecnofix.pro
3. Menos "já ficou pronto?" no WhatsApp 😅 O cliente acompanha o conserto pelo link. tecnofix.pro
4. Comprovante com QR code e certificado de garantia na hora. 🧾 Teste grátis 14 dias: tecnofix.pro
5. Quanto sua assistência faturou este mês? 📊 Descubra em segundos: tecnofix.pro
6. (vídeo da OS) Uma OS completa em menos de 1 minuto ⏱️ tecnofix.pro

---

## Mensagem de WhatsApp para assistências (abordagem)

Mande para assistências que você já conhece ou que pediram informação.
Personalize o nome e não envie em massa para quem nunca falou com você
(o WhatsApp bloqueia números denunciados).

> Oi, [nome]! Tudo bem? Aqui é o Bruno.
> Lancei o **TecnoFix**, um sistema feito para assistência técnica. Com ele você:
> • abre a OS em menos de 1 minuto, com fotos e checklist
> • manda um link pro cliente acompanhar o conserto e aprovar o orçamento pelo celular
> • imprime comprovante com QR code e certificado de garantia
> • vê caixa e faturamento do mês num painel só
>
> Dá pra testar **grátis por 14 dias, sem cartão**: tecnofix.pro
> Se quiser, te mostro em 10 minutos por vídeo. Posso te mandar um vídeo curto de como funciona?

**Se a pessoa responder "manda o vídeo":** envie `video-aprovacao-celular-stories.mp4` ou `gravacao-nova-os-computador.mp4`.

**Lembrete (3 a 5 dias depois, só se não houve resposta):**

> Oi, [nome]! Conseguiu dar uma olhada no TecnoFix? Se ficou alguma dúvida, me fala que eu te ajudo a configurar. O teste é grátis por 14 dias: tecnofix.pro

---

## Legenda para post orgânico (Instagram/Facebook)

> Sua assistência merece mais do que caderno e planilha. 🔧
> Com o TecnoFix você abre OS em menos de 1 minuto, o cliente acompanha o conserto e aprova o orçamento pelo celular, e você imprime comprovante e garantia na hora.
> Teste grátis por 14 dias, sem cartão. Link na bio.
>
> #assistenciatecnica #consertodecelular #manutencaodecelular #assistenciatecnicacelular #ordemdeservico #lojadecelular #tecnicoemcelular #conserto

---

## Como montar no Meta (sugestão para começar)

- **Objetivo:** Tráfego (para o site). Quando o Pixel do Meta estiver instalado no cadastro, troque para Cadastros/Conversões.
- **Público:** Brasil (ou sua região), 22–55 anos, interesses como *assistência técnica*, *conserto de celular*, *manutenção de computadores*, *peças para celular*.
- **Posicionamentos:** automáticos. Suba o par de cada criativo (feed 1080×1080 e stories 1080×1920); o Meta escolhe o formato certo para cada lugar.
- **Teste:** coloque 3–5 criativos no mesmo conjunto e deixe rodar uns 5–7 dias antes de julgar. Desligue os que tiverem custo por clique bem acima dos outros.
- **Vídeos:** estão sem som. No Reels, vale escolher uma música da biblioteca do próprio Instagram na hora de publicar.

---

## O que tem no kit

- `criativos/` — 10 imagens prontas: 5 feed (1080×1080) + 5 stories/Status (1080×1920)
- `videos-anuncio/` — 6 vídeos com marca e chamada: 3 stories (1080×1920) + 3 feed (1080×1350)
- `videos-gravacoes/` — as 3 gravações limpas, sem moldura, para editar (CapCut etc.)
- `prints/` — 24 telas do sistema (computador e celular) com dados de demonstração

Todos os dados que aparecem (clientes, valores, a "Assistência Tech São Paulo") são fictícios.
